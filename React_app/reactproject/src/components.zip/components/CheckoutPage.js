import React from 'react'

export const CheckoutPage = () => {
  return (
    <div>CheckoutPage</div>
  )
}
